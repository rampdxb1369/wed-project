<?php
if(isset($_POST['action']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $country=$_POST['country'];
    $service=$_POST['service'];
    $guest=$_POST['guest'];
    $date=$_POST['date'];
    $budget=$_POST['budget'];
    $message=$_POST['message'];
    
    $client_to=$email;
    $client_subject="Thankyou For Submitting Enquiry | HAYATY WEDDING PLANNERS";
    $client_message="
    <html>
    <head>
    </head>
    <body>
    <h1><strong>YOUR ENQUIRY GOT SUBMITTED SUCCESSFULLY</strong></h1>
    <p>Your enquiry has got submitted successfully.Our team will be in touch with you shortly.</p>
    <p>This is auto-generated email,for inquiries/issue please connect via email : info@hayaty.ae</p>
    </body>
    </html>
    ";
    
     // Always set content-type when sending HTML email
    $client_headers = "MIME-Version: 1.0" . "\r\n";
    $client_headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $client_headers .= 'From: <no-reply@hayaty.ae>' . "\r\n";
    
 
    
    $to = "weddings@hayaty.ae";
    $subject = "Event Inquiry | HAYATY EVENT PLANNERS";
    
    $message = "
    <html>
    <head>
    <style>
        #customers {
          font-family: Arial, Helvetica, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        #customers td, #customers th {
          border: 1px solid #ddd;
          padding: 8px;
        }
        
        #customers tr:nth-child(even){background-color: #f2f2f2;}
        
        #customers tr:hover {background-color: #ddd;}
        
        #customers th {
          padding-top: 12px;
          padding-bottom: 12px;
          text-align: left;
          background-color: #04AA6D;
          color: white;
        }
    </style>
    <title>HTML email</title>
    </head>
    <body>
    <p>All the details of the inquiry are listed below :</p>
    <table id='customers'>
    <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Country</th>
    <th>Services</th>
    <th>Guest</th>
    <th>Date Of Event</th>
    <th>Approx. Budget</th>
    <th colspan='3'>Message</th>
    </tr>
    <tr>
    <td>".$name."</td>
    <td>".$email."</td>
    <td>".$phone."</td>
    <td>".$country."</td>
    <td>".$service."</td>
    <td>".$guest."</td>
    <td>".$date."</td>
    <td>".$budget."</td>
    <td colspan='3'>".$message."</td>
    </tr>
    </table>
    </body>
    </html>
    ";
    
    // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    
    // More headers
    $headers .= 'From: <no-reply@hayaty.ae>' . "\r\n";
    
    if(mail($to,$subject,$message,$headers) && mail($client_to,$client_subject,$client_message,$client_headers))
    {
        echo 'success';
    }
    else
    {
        echo 'failure';
    }

}

?>